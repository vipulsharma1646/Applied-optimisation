# main.py
import numpy as np
from quantum.circuit import VariationalCircuit
from quantum.hamiltonian import Hamiltonian
from quantum.metrics import calculate_fidelity, calculate_depth, calculate_variance
from optimizer.augmented_lagrangian import AugmentedLagrangianOptimizer
from utils.logger import log_iteration
from utils.plotter import plot_cost_and_constraints
from config import CONFIG

def main():
    # Initialize quantum circuit and Hamiltonian
    num_qubits = CONFIG['num_qubits']
    reps = CONFIG['reps']
    circuit = VariationalCircuit(num_qubits=num_qubits, reps=reps)
    hamiltonian = Hamiltonian()

    # Define optimizer
    optimizer = AugmentedLagrangianOptimizer(
        cost_function=hamiltonian.calculate_cost,
        constraints=[calculate_fidelity, calculate_depth, calculate_variance],
        max_depth=CONFIG['max_depth'],
        min_fidelity=CONFIG['min_fidelity'],
        max_variance=CONFIG['max_variance']
    )
    
    # Start optimization
    initial_params = np.random.uniform(0, 2 * np.pi, circuit.num_params)
    results = optimizer.optimize(circuit, initial_params)
    
    # Plot results
    plot_cost_and_constraints(results['costs'], results['constraints'], file_name="optimization_results.png")

    # Final log
    log_iteration(iteration=len(results['costs']), cost=results['costs'][-1], constraints=results['constraints'][-1])

if __name__ == "__main__":
    main()
