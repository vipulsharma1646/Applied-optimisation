from qiskit.opflow import I, X, Z, Y, PauliSumOp

def get_simple_hamiltonian(num_qubits: int) -> PauliSumOp:
    """
    Constructs a simple Ising-like Hamiltonian: H = Z_0 Z_1 + X_0 + X_1 + ...
    This can be modified later to load more complex Hamiltonians.
    """
    if num_qubits < 2:
        raise ValueError("Number of qubits must be >= 2")

    # First interaction term: Z_0 Z_1
    hamiltonian = (Z ^ Z ^ I.tensorpower(num_qubits - 2))

    # Add X_i terms
    for i in range(num_qubits):
        term = [I] * num_qubits
        term[i] = X
        hamiltonian += term[0]
        for j in range(1, num_qubits):
            hamiltonian = hamiltonian.tensor(term[j])

    return PauliSumOp.from_operator(hamiltonian.to_matrix())
