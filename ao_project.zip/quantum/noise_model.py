from qiskit.providers.aer.noise import NoiseModel, depolarizing_error, thermal_relaxation_error
from qiskit.providers.aer.noise import errors
from qiskit.providers.aer.noise.errors import pauli_error
from qiskit import IBMQ


def get_simple_noise_model(p1=0.01, p2=0.02, readout_error=0.03) -> NoiseModel:
    """
    Constructs a simple noise model with depolarizing gate errors and readout errors.
    """
    noise_model = NoiseModel()

    # Depolarizing errors
    noise_model.add_all_qubit_quantum_error(depolarizing_error(p1, 1), ['u1', 'u2', 'u3'])
    noise_model.add_all_qubit_quantum_error(depolarizing_error(p2, 2), ['cx'])

    # Readout error
    from qiskit.providers.aer.noise.errors import ReadoutError
    readout_err = ReadoutError([[1 - readout_error, readout_error], [readout_error, 1 - readout_error]])
    noise_model.add_all_qubit_readout_error(readout_err)

    return noise_model


def get_basis_gates_from_noise_model(noise_model: NoiseModel):
    return noise_model.basis_gates
