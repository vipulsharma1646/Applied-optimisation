from qiskit import QuantumCircuit
from qiskit.circuit import ParameterVector


class VariationalCircuit:
    def __init__(self, num_qubits: int, reps: int = 2):
        self.num_qubits = num_qubits
        self.reps = reps
        self.num_params = self.num_qubits * self.reps * 2
        self.params = ParameterVector('θ', self.num_params)
        self.circuit = self._build_ansatz()

    def _build_ansatz(self) -> QuantumCircuit:
        qc = QuantumCircuit(self.num_qubits)
        param_idx = 0

        for _ in range(self.reps):
            for qubit in range(self.num_qubits):
                qc.ry(self.params[param_idx], qubit)
                param_idx += 1
            for qubit in range(self.num_qubits):
                qc.rz(self.params[param_idx], qubit)
                param_idx += 1
            for qubit in range(self.num_qubits - 1):
                qc.cx(qubit, qubit + 1)

        return qc

    def get_circuit(self) -> QuantumCircuit:
        return self.circuit

    def get_parameters(self) -> ParameterVector:
        return self.params

    def bind_parameters(self, theta_values: list[float]) -> QuantumCircuit:
        if len(theta_values) != self.num_params:
            raise ValueError("Incorrect number of parameters")
        return self.circuit.bind_parameters({p: v for p, v in zip(self.params, theta_values)})
