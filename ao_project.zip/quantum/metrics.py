from qiskit.quantum_info import state_fidelity, Statevector, partial_trace, DensityMatrix
from qiskit import transpile
from qiskit_aer import AerSimulator
import numpy as np

def compute_fidelity(state_ideal, state_actual) -> float:
    """Compute fidelity between two quantum states."""
    return state_fidelity(state_ideal, state_actual)

def compute_variance(counts: dict, shots: int) -> float:
    """Compute variance of measurement results given shot counts."""
    probabilities = np.array([v / shots for v in counts.values()])
    mean = np.sum(probabilities)
    var = np.sum((probabilities - mean) ** 2)
    return var

def compute_circuit_depth(qc) -> int:
    """Get the depth of the quantum circuit."""
    return qc.depth()

def get_noisy_state(circuit, noise_model, basis_gates, coupling_map=None):
    """
    Simulates the circuit with noise and returns a density matrix.
    """
    simulator = AerSimulator(method="density_matrix", noise_model=noise_model, basis_gates=basis_gates, coupling_map=coupling_map)
    compiled_circuit = transpile(circuit, simulator)
    result = simulator.run(compiled_circuit).result()
    return result.data(0)['density_matrix']
