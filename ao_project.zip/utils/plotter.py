import matplotlib.pyplot as plt


def plot_optimization_history(history, constraint_names=None):
    """
    Plots cost function over iterations and optionally constraint values.
    """
    costs = [item[1] for item in history]
    plt.figure(figsize=(8, 5))
    plt.plot(costs, label='Cost Function', linewidth=2)
    plt.xlabel("Iteration")
    plt.ylabel("Cost")
    plt.title("Optimization Progress")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.show()
