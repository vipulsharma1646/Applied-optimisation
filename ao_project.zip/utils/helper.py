# helpers.py
import numpy as np
from qiskit.quantum_info import state_fidelity
from qiskit.visualization import plot_histogram

def flatten_params(params):
    """
    Flatten parameter vector if provided as a list of lists.
    """
    return np.concatenate([np.array(p).flatten() for p in params])

def normalize_counts(counts):
    """
    Normalize the counts into a probability distribution.
    """
    total = sum(counts.values())
    return {key: value / total for key, value in counts.items()}

def average_fidelity(target_state, measured_state, num_qubits):
    """
    Calculate the average fidelity between the target and measured states.
    """
    return state_fidelity(target_state, measured_state)

def plot_cost_and_constraints(costs, constraints, file_name="optimization_plot.png"):
    """
    Plot cost function and constraints violation over optimization steps.
    """
    import matplotlib.pyplot as plt
    
    fig, ax1 = plt.subplots()

    ax1.set_xlabel('Optimization Iterations')
    ax1.set_ylabel('Cost', color='tab:blue')
    ax1.plot(costs, color='tab:blue', label='Cost')
    ax1.tick_params(axis='y', labelcolor='tab:blue')

    ax2 = ax1.twinx()
    ax2.set_ylabel('Constraint Violation', color='tab:red')
    ax2.plot(constraints, color='tab:red', label='Constraint Violation', linestyle='--')
    ax2.tick_params(axis='y', labelcolor='tab:red')

    fig.tight_layout()
    plt.title("Cost and Constraints Evolution")
    plt.savefig(file_name)
    plt.show()
