import datetime


def log(msg: str, level: str = "INFO"):
    """
    Prints a timestamped log message.
    """
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{timestamp}] [{level}] {msg}")


def log_iteration(iter_num: int, cost: float, grad_norm: float, constraints: list[float]):
    constraint_str = ", ".join([f"c{i + 1}={c:.4f}" for i, c in enumerate(constraints)])
    log(f"Iter {iter_num:03d} | Cost = {cost:.6f} | Grad Norm = {grad_norm:.4e} | Constraints: [{constraint_str}]")
