import numpy as np

class AugmentedLagrangianOptimizer:
    def __init__(self, obj_func, constraints, initial_theta, lambda_init=None, mu=10.0, tol=1e-3, max_iter=100):
        self.obj_func = obj_func                      # Objective function: f(x)
        self.constraints = constraints                # List of constraint functions: [g1(x), g2(x), ...]
        self.theta = np.array(initial_theta)          # Initial parameters
        self.lambda_ = np.zeros(len(constraints)) if lambda_init is None else np.array(lambda_init)
        self.mu = mu                                  # Penalty parameter
        self.tol = tol                                # Tolerance for convergence
        self.max_iter = max_iter                      # Max iterations

    def solve(self):
        history = []
        for iteration in range(self.max_iter):
            def augmented_lagrangian(theta):
                val = self.obj_func(theta)
                for i, g in enumerate(self.constraints):
                    c_i = g(theta)
                    val += self.lambda_[i] * c_i + (self.mu / 2.0) * c_i ** 2
                return val

            grad = self._finite_difference_gradient(augmented_lagrangian, self.theta)
            step_size = 0.1  # could use line search or adaptive methods
            self.theta = self.theta - step_size * grad

            constraint_vals = np.array([g(self.theta) for g in self.constraints])

            # Update Lagrange multipliers
            self.lambda_ = self.lambda_ + self.mu * constraint_vals

            # Convergence check
            if np.linalg.norm(grad) < self.tol and np.all(np.abs(constraint_vals) < self.tol):
                break

            history.append((self.theta.copy(), augmented_lagrangian(self.theta)))

        return self.theta, history

    def _finite_difference_gradient(self, f, x, eps=1e-5):
        grad = np.zeros_like(x)
        for i in range(len(x)):
            x_eps1 = np.array(x, copy=True)
            x_eps2 = np.array(x, copy=True)
            x_eps1[i] += eps
            x_eps2[i] -= eps
            grad[i] = (f(x_eps1) - f(x_eps2)) / (2 * eps)
        return grad
