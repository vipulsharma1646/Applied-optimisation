## config.py

CONFIG = {
    'num_qubits': 4,  # Adjust to the number of qubits you want to use
    'reps': 2,        # Number of repetitions (layers) in the circuit
    'max_depth': 10,  # Max allowed circuit depth
    'min_fidelity': 0.95,  # Min fidelity to the target state
    'max_variance': 0.05,  # Max allowable variance in measurements
    'optimizer_tolerance': 1e-5,
    'optimizer_max_iter': 200
}